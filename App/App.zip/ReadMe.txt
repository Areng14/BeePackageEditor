Whatever you do DO NOT REMOVE DATA FOLDER.
